<!-- Fee Info -->
<div class="col-6">
    <div class="card  bg-secondary shadow">
        <div class="card-header border-0">
            <div class="row align-items-center">
                <div class="col-8">
                    <h3 class="mb-0">Подключить Stripe</h3>
                </div>
                <div class="col-4 text-right">
                </div>
            </div>
        </div>
        <div class="card-body">
         <p>
            Мы используем Stripe для сбора платежей. Подключитесь сейчас, и мы отправим ваши средства из корзины платежей прямо на ваш счет Stripe.<br />
             <hr />
             @if (!auth()->user()->stripe_account)
                <a href="{{ route('stripe.connect')}}" class="btn btn-primary">Подключиться с помощью Stripe Connect</a>
             @else

             <div class="row">
                 <div class="col-md-6">
                    <h4>{{__('Stripe account')}}</h4>
                    {{auth()->user()->stripe_account}}
                 </div>
                 <div class="col-md-6">
                    <h4>{{__('Stripe details submited')}}</h4>
                    {{$stripe_details_submitted}}
                 </div>
             </div>
             <br />
             <a href="{{ route('stripe.connect')}}" class="btn btn-warning">{{ __('Update Stripe connection') }}</a>
             @endif
        </p>
        </div>
    </div>
</div>