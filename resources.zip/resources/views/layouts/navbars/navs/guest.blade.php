<nav class="navbar navbar-top navbar-horizontal navbar-expand-md bg-white navbar-dark">
    <div class="container-fluid px-7">
        <a class="navbar-brand" href="/">
            <img height="40px" src="{{ config('global.site_logo') }}" />
        </a>
    </div>
</nav>
