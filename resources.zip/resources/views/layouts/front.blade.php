
<!DOCTYPE html>
<html lang="ru-RU">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="{{ asset('argonfront') }}/img/apple-icon.png">
    <link rel="icon" type="image/png" href="{{ asset('argonfront') }}/img/favicon.png">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta property="og:image" content="{{ config('global.site_logo') }}">
    <title>{{ config('global.site_name','Aston') }}</title>

    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link href="{{ asset('argonfront') }}/css/font-awesome.css" rel="stylesheet" />
    <link href="{{ asset('argonfront') }}/css/nucleo-svg.css" rel="stylesheet" />
    <link href="{{ asset('argonfront') }}/css/nucleo-icons.css" rel="stylesheet">

    <!-- CSS Files -->
    <link href="{{ asset('argonfront') }}/css/argon-design-system.min.css?v=1.4.0" rel="stylesheet" />

    <!-- Custom CSS -->
    <link type="text/css" href="{{ asset('custom') }}/css/custom.css" rel="stylesheet">
     <link type="text/css" href="{{ asset('custom') }}/css/stripe.css" rel="stylesheet">
    <!-- Select2 -->
    <link type="text/css" href="{{ asset('custom') }}/css/select2.min.css" rel="stylesheet">
    
        <!-- Elegant font icons -->
    <link href="https://maxartkiller.com/website/oneuiux/mobile/restaurant/assets/vendor/elegant_font/HTMLCSS/style.css" rel="stylesheet">
    <link href="assets/css/style-dark-pink.css" rel="stylesheet" id="style">
    <!-- Elegant font icons -->
    <link href="https://maxartkiller.com/website/oneuiux/mobile/restaurant/assets/vendor/materializeicon/material-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    
<style>
    #progress {
      position: fixed;
      z-index: 100;
      top: 0;
      left: -6px;
      width: 3%;
      height: 5px;
      background: black;
      border-radius: 1px; 
      transition: width 500ms ease-out, opacity 400ms linear;
    }
  </style>
  <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  <script>
    $(function() {	 
      $("#progress").width((50 + Math.random() * 30) + "%");
      $(window).on('load', function() {
        $("#progress").width("101%").delay(300).fadeOut(400);
      });
    });
  </script>


    <!-- Global site tag (gtag.js) - Google Analytics -->
    @if (env('GOOGLE_ANALYTICS',false))
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo env('GOOGLE_ANALYTICS',''); ?>"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());

            gtag('config', '<?php echo env('GOOGLE_ANALYTICS',''); ?>');
        </script>
    @endif

  @include('googletagmanager::head')
  @yield('head')
  @laravelPWA

<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/site.webmanifest">
<link rel="mask-icon" href="/safari-pinned-tab.svg" color="#5bbad5">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="theme-color" content="#ffffff">

<!-- Custom CSS defined by admin -->
<link type="text/css" href="{{ asset('byadmin') }}/front.css" rel="stylesheet">

</head>

<body class="">
    
    
    
    <!-- sticky footer tabs >
    <div class="footer-tabs border-top text-center">
        <ul class="nav nav-tabs justify-content-center" id="myTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">
                    <i class="material-icons">home</i>
                    <small class="sr-only">Home</small>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="search-tab" data-toggle="tab" href="#search" role="tab" aria-controls="search" aria-selected="false">
                    <i class="material-icons">room</i>
                    <small class="sr-only">search</small>
                </a>
            </li>
            <li class="nav-item centerlarge">
                <a class="nav-link bg-default" id="cart-tab" data-toggle="tab" href="#cart" role="tab" aria-controls="cart" aria-selected="false" style="background-color: #f00480!important;">
                    <i class="material-icons" style="position: unset;top: 0px;">shopping_basket</i>
                    <small class="sr-only">chat</small>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="favorite-tab" data-toggle="tab" href="#favorite" role="tab" aria-controls="favorite" aria-selected="false">
                    <i class="material-icons">star</i>
                    <small class="sr-only">Best</small>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">
                    <i class="material-icons">person</i>
                    <small class="sr-only">Account</small>
                </a>
            </li>
        </ul>
    </div>
    <!-- sticky footer tabs -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <div id="progress"></div>
    
    @include('googletagmanager::body')
    @auth()
        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
            @csrf
        </form>
    @endauth

              @if(\Request::route()->getName() != "cart.checkout")
<a id="desCartLink" onclick="openNav()" class="btn btn-neutral btn-icon btn-cart" style="
    position: fixed;
    transform: translateZ(0);
    z-index: 1001;
    left: 0;
    right: 0;
    top: 90%;
    margin-left: 25px;
    margin-right: 25px;
    background: #f00480;
    border-color: #f00480;
    box-shadow: 0 0 13px 8px rgb(255 255 255 / 0%);
    max-width: 360px;
    margin: 0 auto;
    border-radius: 16px;
    box-shadow: 0 0 13px 8px rgb(255 255 255 / 0%);

">
                  <span class="btn-inner--icon">
                    <i class="fa fa-shopping-cart"></i>
                  </span>
                  <span class="nav-link-inner--text" >Корзина</span>
                  <i data-v-1aa65e07="" style="
    display: block;
    position: absolute;
    right: 11px;
    top: 5px;
    height: 30px;
    line-height: 30px;
    font-size: 12px;
    font-weight: 500;
    color: #fff;
    padding-left: 12px;
    padding-right: 12px;
    font-style: normal;
    border-radius: 8px;
    background: rgb(142 13 81);
    text-transform: none;
">{{Cart::getSubtotal()}}&nbsp;сом</i>
             
              </a>
              @endif

    <!-- Navbar -->
    @if(config('app.isft'))
        @include('layouts.menu.top')
    @else
        @include('layouts.menu.top_justlogo')
    @endif

    <!-- End Navbar -->
    <div class="wrapper">
        @yield('content')
        @include('layouts.navbars.cartSideMenu')
        @include('layouts.footers.front')
        @if(request()->get('location') )
            @include('layouts.headers.modallocation')
        @endif
    </div>

    <!--   Core JS Files   -->
    <script src="{{ asset('argonfront') }}/js/core/jquery.min.js" type="text/javascript"></script>
    <script src="{{ asset('argonfront') }}/js/core/popper.min.js" type="text/javascript"></script>
    <script src="{{ asset('argonfront') }}/js/core/bootstrap.min.js" type="text/javascript"></script>
    <script src="{{ asset('argonfront') }}/js/plugins/perfect-scrollbar.jquery.min.js"></script>

    <!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
    <script src="{{ asset('argonfront') }}/js/plugins/bootstrap-switch.js"></script>

    <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
    <script src="{{ asset('argonfront') }}/js/plugins/nouislider.min.js" type="text/javascript"></script>
    <script src="{{ asset('argonfront') }}/js/plugins/moment.min.js"></script>

    <script src="{{ asset('argonfront') }}/js/plugins/datetimepicker.js" type="text/javascript"></script>
    <script src="{{ asset('argonfront') }}/js/plugins/bootstrap-datepicker.min.js"></script>

    <!-- Control Center for Argon UI Kit: parallax effects, scripts for the example pages etc -->
    <script src="{{ asset('argonfront') }}/js/argon-design-system.js?v=1.2.0" type="text/javascript"></script>


   <!-- Import Vue -->
   <script src="{{ asset('vendor') }}/vue/vue.js"></script>
   <!-- Import AXIOS --->
   <script src="{{ asset('vendor') }}/axios/axios.min.js"></script>

    <!-- Add to Cart   -->
    <script>
        var LOCALE="<?php echo  App::getLocale() ?>";
        var CASHIER_CURRENCY = "<?php echo  env('CASHIER_CURRENCY','usd') ?>";
        var USER_ID = '{{  auth()->user()?auth()->user()->id:"" }}';
        var PUSHER_APP_KEY = "{{ env('PUSHER_APP_KEY',"") }}";
    </script>
    <script src="{{ asset('custom') }}/js/cartFunctions.js"></script>


    <!-- Cart custom sidemenu -->
    <script src="{{ asset('custom') }}/js/cartSideMenu.js"></script>

    <!-- Notify JS -->
    <script src="{{ asset('custom') }}/js/notify.min.js"></script>

     <!-- SELECT2 -->
     <script src="{{ asset('custom') }}/js/select2.js"></script>
     <script src="{{ asset('vendor') }}/select2/select2.min.js"></script>

    <!-- All in one -->
    <script src="{{ asset('custom') }}/js/js.js?id={{ config('config.version')}}"></script>




     <!-- Google Map -->
     <script async defer src="https://maps.googleapis.com/maps/api/js?libraries=geometry,drawing&key=<?php echo env('GOOGLE_MAPS_API_KEY',''); ?>&libraries=places&callback=js.initializeGoogle"></script>

    @if(strlen( env('PUSHER_APP_ID',""))>2)
        <!-- Pusher -->
        <script src="https://js.pusher.com/7.0/pusher.min.js"></script>
        <script src="{{ asset('custom') }}/js/pusher.js"></script>
    @endif

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    @yield('js')

    <!-- Custom JS defined by admin -->
    <?php echo file_get_contents(base_path('public/byadmin/front.js')) ?>

</body>

</html>
