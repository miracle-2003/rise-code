<?php

return [
    'him_self' => 'Customer',
    'by_restaurant'=>'Restaurant',
    'created_by'=>"Created by",
    'visit_time'=>"Visit time",
    'back'=>"Back",
];